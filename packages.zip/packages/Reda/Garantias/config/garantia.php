<?php

// El archivo debe devolver un array asociativo
return [

    /*
    |--------------------------------------------------------------------------
    | Reda Garantias Module Configuration
    |--------------------------------------------------------------------------
    | Este es el archivo de configuración para el módulo Reda Garantias.
    | Aquí puedes sobrescribir valores por defecto, prefijos, o ajustes de la base de datos.
    */

    'module_version' => '1.0',

    // Puedes añadir aquí tus primeras configuraciones futuras, como:
    // 'api_prefix' => 'api/garantias',
    // 'table_name' => 'garantias',

];