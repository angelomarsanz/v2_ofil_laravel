<?php

namespace Reda\Garantias\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
// Importas el modelo original de Laravel, no necesitas crear uno nuevo
use App\Models\User; 
use Illuminate\Support\Facades\Auth;

class UsuarioController extends Controller
{
    /**
     * Verificar si el usuario está autenticado y devolver sus datos
     */
    public function verificarUsuarioConectado()
    {
		$usuario_administrador = '';
		$id_usuario_agencia = 0;
		$id_usuario_conectado = 0;
		$rol_usuario_conectado = 0;
		$tipo_agencia_agente = '';

        // Obtener el usuario que está logueado actualmente
        $user = Auth::user();

        if (!$user) {
            return response()->json([
                'codigo_retorno' => 1,
                'mensaje' => 'Usuario no autenticado'
            ], 401);
        }

        // Aquí puedes estructurar lo que React necesita
        return response()->json([
			'codigo_retorno' => 0,
			'mensaje' => 'Verificación exitosa',
			'usuario_administrador' => "No",
			'id_usuario_agencia' => $user->id, // Suponiendo que es una agencia
			'id_usuario_conectado' => $user->id, // Cuando es agencia, el id del usuario conectado es el mismo
			'rol_usuario_conectado' => 3, // 2 = Agente, 3 = Agencia
			'tipo_agencia_agente' => "estate_agency"
        ], 200);
    }
}