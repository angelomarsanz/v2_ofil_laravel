<?php

namespace Reda\Garantias;

use Illuminate\Support\ServiceProvider;

class GarantiasServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../config/garantia.php', 'garantia');
    }

    public function boot(): void
    {
        // 1. Carga de Rutas
        $this->loadRoutesFrom(__DIR__.'/../routes/web.php');

        // 2. Carga de Vistas con el namespace 'garantias'
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'garantias');

        // 3. Carga de Migraciones (descomentar si agregas tablas)
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');

       // 4. PUBLICACIÓN DE CONFIGURACIÓN
        $this->publishes([
            __DIR__.'/../config/garantia.php' => config_path('garantia.php'),
        // Nueva etiqueta
        ], 'garantia-config');
    }
}