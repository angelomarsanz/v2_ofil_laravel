export { Arrendatario } from "./Arrendatario";
export { DatosGarantia } from "./DatosGarantia";