export const GifEspere = () => {
  return (
    <div className='ra_gif_espere'>
      <img
        src='https://dev-backend.ofiliaria.com/public/imagenes/loading.gif'
        alt='Por favor espere'
        style={{
          width: 90,
          height: 90
        }}
      />
    </div>
  );
};