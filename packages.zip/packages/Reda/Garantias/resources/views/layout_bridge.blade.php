{{-- Extiende el layout del Dashboard de Usuario --}}
@extends('user.layout')

@section('styles')
    {{-- Inyectamos los estilos compilados del plugin de Garantías --}}
    <link rel="stylesheet" href="{{ asset('css/garantias.css?v=' . time()) }}">

    {{-- EL TOKEN CSRF AQUÍ --}}
    {{-- Lo ponemos al final de los estilos para que esté listo antes de los scripts --}}
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    {{-- Permitimos que las vistas inyecten más estilos si lo necesitan --}}
    @yield('extra_plugin_styles')
@endsection

@section('content')
    {{-- 
       El layout de usuario suele usar @yield('content') para el cuerpo principal.
       Aquí renderizamos el contenido específico del plugin.
    --}}
    @yield('contenido_del_plugin')
@endsection

@section('scripts')
    {{-- Inyectamos el archivo JavaScript compilado de React para Garantías --}}
    <script src="{{ asset('js/garantias.js?v=' . time()) }}"></script>
    
    {{-- Permitimos que las vistas inyecten más scripts si lo necesitan --}}
    @yield('extra_plugin_scripts')
@endsection