@extends('garantias::layout_bridge')

@section('contenido_del_plugin')
    <div>Garantías</div>
    <div id='indexGarantias'></div>
@endsection