<?php

use Illuminate\Support\Facades\Route;
use Reda\Garantias\Http\Controllers\GarantiaController;
use Reda\Garantias\Http\Controllers\CategoriaController;

Route::get('test-garantias', function () {
    return '¡El plugin de Garantías está funcionando perfectamente!';
});

// Proteger la ruta y exponerla en '/user/garantias/categorias'
Route::group(['prefix' => 'user', 'middleware' => ['auth:web', 'userstatus', 'TenantDashboardLang']], function () {
    Route::get('garantias/usuario/verificar', [\Reda\Garantias\Http\Controllers\UsuarioController::class, 'verificarUsuarioConectado'])->name('reda.garantias.usuario.verificar');  
    Route::get('garantias', [GarantiaController::class, 'index'])->name('reda.garantias.index');
    Route::get('garantias/categorias', [CategoriaController::class, 'index'])->name('reda.garantias.categorias.index');
});