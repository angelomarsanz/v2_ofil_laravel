<?php

// El archivo debe devolver un array asociativo
return [

    /*
    |--------------------------------------------------------------------------
    | Reda Integraciones Module Configuration
    |--------------------------------------------------------------------------
    | Este es el archivo de configuración para el módulo Reda Integraciones.
    | Aquí puedes sobrescribir valores por defecto, prefijos, o ajustes de la base de datos.
    */

    'module_version' => '1.0',

    // Puedes añadir aquí tus primeras configuraciones futuras, como:
    // 'api_prefix' => 'api/integraciones',
    // 'table_name' => 'reda_integraciones',

];