
// Importamos el packages/Reda/Integraciones/resources/sass/main.scss
import '../sass/main.scss';

// Importamos los scripts de cada una de las vistas.
// Webpack los incluirá todos en el archivo compilado reda.js.
// Importamos packages/Reda/Integraciones/resources/js/vistas/mercado_libre/importadores/indexImportadores.js
import './vistas/mercado_libre/importadores/indexImportadores.js';